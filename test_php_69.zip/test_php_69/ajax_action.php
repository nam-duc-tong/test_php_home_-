<?php
      $con = mysqli_connect("localhost","root","","datamanager");
      $action = $_POST["action"];
      if($action=="Insert"){ 
        $name = mysqli_real_escape_string($con,$_POST["name"]);
        $gender = mysqli_real_escape_string($con,$_POST["gender"]);
        $contact = mysqli_real_escape_string($con,$_POST["contact"]);
        $sql = "Insert into user (Name,Gender,Contact) value('{$name}','{$gender}','{$contact}')";
        if($con->query($sql))
        {
            echo "<tr>
                    <td>$name</td>
                    <td>$gender</td>
                    <td>$contact</td>
                    <td><a href='#' class='btn btn-primary edit'>Edit</a></td>
                    <td><a href='#' class='btn btn-danger delete'>Delete</a></td>
                </tr>
                ";
        }
        else
        {
                echo false;
        }
      }
      else if($action=="Update")
      {     
            $id = mysqli_real_escape_string($con,$_POST["id"]);
            $name = mysqli_real_escape_string($con,$_POST["name"]);
            $gender = mysqli_real_escape_string($con,$_POST["gender"]);
            $contact = mysqli_real_escape_string($con,$_POST["contact"]);
            $sql = "update user SET Name = '{$name}',Gender='{$gender}',Contact='{$contact}' WHERE Id ='{$id}'";
            if($con->query($sql))
            {
                echo "
                        <td>$name</td>
                        <td>$gender</td>
                        <td>$contact</td>
                        <td><a href='#' class='btn btn-primary edit'>Edit</a></td>
                        <td><a href='#' class='btn btn-danger delete'>Delete</a></td>
                ";
            }
            else
            {
                    echo false;
            }
      }
      else if($action=="delete"){
            $id = $_POST["uid"];
            $sql = "delete from user where Id='{$id}'";
            if($con->query($sql))
            {
                echo true;
            }
            else{
                echo false;
            }
      }
?>