<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script src="http://code.jquery.com/jquery-1.11.0.min.js"></script>
</head>
<body>
<!-- Modal -->
<div class="modal fade" id="modal_frm" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">User Detail</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
            <form id="frm">
                <input type="hidden" name='action' id='action' value='Insert'>
                <input type="hidden" name='id' id='uid' value='0'>
                
                <div class="form-group my-3">
                    <label>Name</label>
                    <input type="text" name='name' id='name' required class ='form-control'>
                </div>
                <div class="form-group my-3">
                    <label>Gender</label>
                    <select name="gender" id="gender" required class="form-control">
                        <option value=''>Select</option>
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                        <option value="Others">Others</option>
                    </select>
                </div>
                <div class="form-group my-3">
                    <label>Contact</label>
                    <input type="text" name='contact' id='contact' required class='form-control'>
                </div>
                <input type="submit" value='Submit' class='btn btn-success'>
            </form>
        </div>
    </div>
  </div>
</div>
<div class="container mt-5">
    <p class="text-right"><a href="#" class='btn btn-success' id="add_record">Add Record</a></p>
    <table class="table table-bordered">
        <thead>
            <th>Name</th>
            <th>Gender</th>
            <th>Contact</th>
            <th>Edit</th>
            <th>Delete</th>
        </thead>
        <tbody id='tbody'>
            <?php
                $con = mysqli_connect("localhost","root","","datamanager");
                $sql = "select * from user";
                $res = $con->query($sql);
                while($row = $res->fetch_assoc()) {
                    echo "
                        <tr uid='{$row["Id"]}'>
                            <td>{$row["Name"]}</td>
                            <td>{$row["Gender"]}</td>
                            <td>{$row["Contact"]}</td>
                            <td><a href='#' class='btn btn-primary edit'>Edit</a></td>
                            <td><a href='#' class='btn btn-danger delete'>Delete</a></td>
                        </tr>
                    ";
                }
            ?>
        </tbody>
    </table>
    </div>
    <script>
        $(document).ready(function(){
            var current_row = null;
            $("#add_record").click(function(){
                $("#modal_frm").modal("show");
            });
            $("#frm").submit(function(event){
                event.preventDefault();
                $.ajax({
                    url:"ajax_action.php",
                    type:"post",
                    data:$("#frm").serialize(),
                    beforeSend:function(){
                        $("#frm").find("input[type='submit']").val('Loading...');
                    },
                    success:function(res){
                        if(res){
                            if($("#uid").val()=="0")
                            {
                                $("#tbody").append(res);
                            }
                            else
                            {
                                $(current_row).html(res);
                            }
                        }
                        else
                        {
                            alert("Failed Try Again");
                        }
                        $("#frm").find("input[type='submit']").val('Submit');
                        clear_input();
                        $("#modal_frm").modal('hide');
                    }
                });
            });
            $("body").on("click",".edit",function(){
                event.preventDefault();
                current_row = $(this).closest("tr");
                $("#modal_frm").modal('show');
                var id = $(this).closest("tr").attr("uid");
                var name = $(this).closest("tr").find("td:eq(0)").text();
                var gender = $(this).closest("tr").find("td:eq(1)").text();
                var contact = $(this).closest("tr").find("td:eq(2)").text();
                $("#action").val("Update");
                $("#uid").val(id);
                $("#name").val(name);
                $("#gender").val(gender);
                $("#contact").val(contact);
            });
            $("body").on("click",".delete",function(){
                event.preventDefault();
                var id = $(this).closest("tr").attr("uid");
                var cls = $(this);
                if(confirm("Are You Sure"))
                {
                    $.ajax({
                        url: "ajax_action.php",
                        type:"post",
                        data:{uid:id,action:'delete'},
                        beforeSend:function(){
                            $(cls).text("loading...");
                        },
                        success:function(res){
                            if(res)
                            {
                                $(cls).closest("tr").remove();
                            }
                            else
                            {
                                alert("Failed try again");
                                $(cls).text("Try Again");
                            }
                        }
                    });
                }
            });
            function clear_input(){
                $("#frm").find(".form-control").val("");
                $("#action").val("Insert");
                $("#uid").val("0");
            }
        });
    </script>
    </body>
</html>
